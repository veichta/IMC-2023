from .errors import ShapeError, SizeMismatchError, LabeledShapeError
from .dimcheck import ShapeChecker, dimchecked
